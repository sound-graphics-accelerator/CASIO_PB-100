tool_bas2load 1.3
Copyright (C) 2026 Arunaizoku  https://github.com/sound-graphics-accelerator
Converts CASIO PB-100 BASIC text into the format the PB-100 reads with LOAD.

- Requirements
  Windows. tool_bas2load.exe runs on its own.

- Usage
  tool_bas2load name.bas              create name.load.txt
  tool_bas2load name.bas out.txt      specify the output file
  tool_bas2load -n NAME name.bas      set the file name the PB-100 shows at LOAD (PF:NAME)
                                      (default: the input file name before the first '.',
                                       up to 8 characters)
  tool_bas2load -d received_log.txt   decode a SAVE log from the PB-100 back to BASIC text
  tool_bas2load -v                    show the version
  tool_bas2load [help]                show help (help can be omitted)

- LOAD procedure
  1) Run LOAD on the PB-100
  2) Send the created file from a terminal program using file transfer

- Writing BASIC text
  - Line numbers 1-9999, in increasing order
  - The file can be UTF-8 (with or without BOM) or Shift_JIS. Only the PB-100 characters
    matter, so the result is the same; other characters (e.g. Japanese) become '?' with a warning.
  - Write PB-100 special characters with a backslash (e.g. \NE  \LE  \GE  \PI  \\ for yen)
  - Characters, escapes and commands not in the table are replaced with '?'
    (unknown commands are written as separate letters) and a warning is shown.

- Definition file (optional)
  Put tool_bas2load_codes.tsv in the same folder as tool_bas2load.exe to add to or
  overwrite the character/command table. See tool_bas2load_codes.sample.tsv.

- Notes
  - Tested only on the author's own PB-100 (original model).
  - This tool comes with no warranty. Use it at your own risk.
  - Whether official support will be provided is undecided.
