﻿tool_pbkey V1.0
Copyright (C) 2026 Arunaizoku  https://github.com/sound-graphics-accelerator

==============================================================================
 日本語
==============================================================================
CASIO PB-100 を Windows のキーボードとして使うツールです。
PB-100 で押したキーを MODE 7 で送り、Windows のソフトに入力します。

■ 必要なもの
  Windows と、PB-100 用の USB シリアル変換モジュール。
  既定の設定は次のモジュールを前提にしています (CH340、9600bps)。
    CASIO PB-100シリーズ用USBシリアル変換モジュール
    https://booth.pm/ja/items/4646432

■ 使い方
  1) PB-100 に pbkey を LOAD して RUN する (pbkey.load.txt をターミナルソフトで送る)。
  2) tool_pbkey.exe を起動する。タスクトレイに Enter キーのアイコンが出る。
     緑 = ONLINE、灰色 = OFFLINE (ポート待ち)
  3) 入力したいソフトの窓をクリックし、PB-100 のキーを押す。
  4) 終わるときはアイコンを右クリック > Exit。

■ / キー (割り当ては tool_pbkey_keys.txt で変更可)
  /N Enter  // /  /B BS  /D Del  /T Tab  /E Esc
  /8 ↑ /2 ↓ /4 ← /6 → /7 Home /1 End /9 PgUp /3 PgDn /0 Ins
  /L 小文字モード  /K 漢字モード (ローマ字 → SPC で変換 → /N で確定)
  /W Windows キー  /Q Alt+F4  /A /C /V /X /Z /S = Ctrl+A C V X Z S  /F1〜/F9, /F0 = F1〜F10

■ ほかのモジュール・ポートを使うとき
  アイコンを右クリック > Port で一覧から選ぶか、
  Edit Settings で tool_pbkey_settings.txt を書き換えます。
    PORT  AUTO (FIND の語を含むポートを自動で使う) または COM5 など
    FIND  AUTO で探す語 (既定 CH340)
    BAUD  速さ (既定 9600)    FLOW  XONXOFF / NONE
  起動時に -p COM5 と指定することもできます。

■ 注意
  作者の PB-100 (無印) でのみ確認。無保証、自己責任でお使いください。

==============================================================================
 English
==============================================================================
Uses the CASIO PB-100 as a Windows keyboard.
Keys pressed on the PB-100 are sent through MODE 7 and typed into Windows programs.

- Requirements
  Windows and a USB serial interface module for the PB-100.
  The default settings assume this module (CH340, 9600 bps):
    USB serial interface module for the CASIO PB-100 series
    https://booth.pm/ja/items/4646432

- Usage
  1) LOAD pbkey on the PB-100 and RUN it (send pbkey.load.txt with a terminal program).
  2) Start tool_pbkey.exe. An Enter-key icon appears in the taskbar tray.
     green = ONLINE, gray = OFFLINE (waiting for the port)
  3) Click the window to type into, then press keys on the PB-100.
  4) To quit, right-click the icon > Exit.

- / keys (change them in tool_pbkey_keys.txt)
  /N Enter  // /  /B BS  /D Del  /T Tab  /E Esc
  /8 Up /2 Down /4 Left /6 Right /7 Home /1 End /9 PgUp /3 PgDn /0 Ins
  /L lower case mode  /K kanji mode (romaji -> SPC converts -> /N confirms)
  /W Windows key  /Q Alt+F4  /A /C /V /X /Z /S = Ctrl+A C V X Z S  /F1-/F9, /F0 = F1-F10

- Using another module or port
  Right-click the icon > Port and pick a port, or
  Edit Settings and change tool_pbkey_settings.txt:
    PORT  AUTO (use a port whose name contains a FIND word) or COM5 etc.
    FIND  word looked for by AUTO (default CH340)
    BAUD  speed (default 9600)    FLOW  XONXOFF / NONE
  You can also start it with -p COM5.

- Notes
  Tested only on the author's PB-100 (original model). No warranty; use at your own risk.
